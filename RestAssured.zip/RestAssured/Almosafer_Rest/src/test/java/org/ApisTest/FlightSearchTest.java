package org.ApisTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FlightSearchTest {

    ExtentHtmlReporter htmlReporter;
    ExtentReports extent;

    @BeforeTest
    public void setUp() {
        htmlReporter = new ExtentHtmlReporter("flightSearchReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @Test
    public void testGetFlightSearch() {
        ExtentTest test = extent.createTest("GET Flight Search", "Test the GET method of flight search API");

        Response response = given()
                .header("Content-Type", "application/json")
                .when()
                .get("https://ae.almosafer.com/api/v3/flights/flight/search?query=RUH-JED/2023-11-20/2023-11-30/Economy/2Adult");

        test.log(Status.INFO, "Verifying status code and response body");
        response.then()
                .statusCode(200)
                .body("status", equalTo("success"))
                .body("data.searchId", notNullValue());

        test.log(Status.INFO, "Parsing JSON response and extracting searchId");
        JsonPath jsonPath = response.jsonPath();
        String searchId = jsonPath.getString("data.searchId");
        System.out.println("Search ID: " + searchId);

        test.pass("GET Flight Search passed");
    }

    @Test
    public void testPostFlightSearchResult() {
        ExtentTest test = extent.createTest("POST Flight Search Result",
                "Test the POST method of flight search result API");

        Response response = given()
                .header("Content-Type", "application/json")
                .when()
                .get("https://ae.almosafer.com/api/v3/flights/flight/search?query=RUH-JED/2023-11-20/2023-11-30/Economy/2Adult");

        test.log(Status.INFO, "Parsing JSON response and extracting searchId");
        JsonPath jsonPath = response.jsonPath();
        String searchId = jsonPath.getString("data.searchId");
        System.out.println("Search ID: " + searchId);

        test.log(Status.INFO, "Sending POST request to flight search result API");
        test.log(Status.INFO, "Verifying status code and response body");
        given()
                .header("Content-Type", "application/json")
                .body(response.asString())
                .when()
                .post("https://ae.almosafer.com/api/v3/flights/flight/async-search-result")
                .then()
                .statusCode(200)
                .body("status", equalTo("success"))
                .body("data.searchId", equalTo(searchId));

        test.pass("POST Flight Search Result passed");
    }
   

    @Test
    public void additionalAssertions() {
        Response response = given().get("https://example.com/api/resource");
        Assert.assertEquals(response.statusCode(), 200);
        Assert.assertEquals(response.contentType(), "application/json");
        Assert.assertTrue(response.asString().contains("searchResults"));
        Assert.assertTrue(response.asString().contains("flightId"));
        Assert.assertTrue(response.asString().contains("airline"));
        Assert.assertTrue(response.asString().contains("price"));
        Assert.assertTrue(response.asString().contains("departure"));
        Assert.assertTrue(response.asString().contains("arrival"));
    }

     @AfterTest
    public void tearDown() {
        extent.flush();
    }
}
