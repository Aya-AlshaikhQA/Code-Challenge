package org.core.custom_exceptions;

public class UnSupportedOptionsException extends RuntimeException {
}
