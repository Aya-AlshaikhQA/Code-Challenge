package org.core.custom_exceptions;

public class UnSupportedYetException extends RuntimeException {
}
