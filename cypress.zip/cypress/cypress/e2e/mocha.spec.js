/// <reference types = "cypress" />

it ("Log something in cypress", function(){

cy.log("Aya")

})