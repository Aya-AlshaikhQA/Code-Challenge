/// <reference types="cypress" />

// To select a date from the date picker
Cypress.Commands.add('selectDate', (selector, date) => {
  cy.get(selector).then(($datePicker) => {
    const dates = $datePicker.find(`[aria-label^="${date}"]`);
    console.log(`Found ${dates.length} matching dates for ${date}`);

    if (dates.length > 0) {
      cy.wrap(dates).should('exist');
      cy.wrap(dates.first()).click();
      console.log(`Clicked on the first matching date for ${date}`);
    } else {
      console.error(`No matching dates found for ${date}`);
    }
  });
});

describe('Flight Search Test', () => {
  const baseUrl = 'https://global.almosafer.com/en';

  it('To verify flight search and validate results', () => {
    cy.visit(baseUrl);

    // To verify the language
    cy.get('[class*="Modal__Body"]').should('exist');
    cy.get('[class*="cta__continue"]').click();
    cy.get('[class*="Modal__Body"]').should('not.exist');
    cy.wait(2000);

    // Flights page
    cy.get('[data-testid="Header__FlightsNavigationTab"]').click();

    // Generate random data for the flight search
    const origins = ['DXB', 'AUH', 'SHJ', 'JED', 'RUH'];
    const destinations = ['AMM', 'CAI', 'DEL', 'KHI', 'PAR'];
    const randomOrigin = origins[Math.floor(Math.random() * origins.length)];
    const randomDestination = destinations[Math.floor(Math.random() * destinations.length)];

    // Generate current date and future dates
    const currentDate = new Date();
    const formattedCurrentDate = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getDate().toString().padStart(2, '0')}`;
    const randomDepartureDate = new Date(currentDate);
    randomDepartureDate.setDate(currentDate.getDate() + Math.floor(Math.random() * 30));

    // Format dates as 'YYYY-MM-DD'
    const formattedDepartureDate = `${randomDepartureDate.getFullYear()}-${(randomDepartureDate.getMonth() + 1).toString().padStart(2, '0')}-${randomDepartureDate.getDate().toString().padStart(2, '0')}`;

    // Flight search form
    cy.get('[data-testid="FlightSearchBox__FromAirportInput"]').should('exist').type(randomOrigin);
    cy.get('[data-testid="FlightSearchBox__AirportOption0"]').click();
    cy.get('[data-testid="FlightSearchBox__ToAirportInput"]').should('exist').type(randomDestination);
    cy.get('[data-testid="FlightSearchBox__AirportOption0"]').click();

    // Date for departure
    cy.get('[data-testid="FlightSearchBox__FromDateButton"]').should('exist').click();
    cy.selectDate('[data-testid^="FlightSearchCalendar__"]', formattedDepartureDate);

    // Date for return 
    cy.get('[data-testid="FlightSearchBox__ToDateButton"]').should('exist').click();
    const randomReturnDate = new Date(randomDepartureDate);
    randomReturnDate.setDate(randomReturnDate.getDate() + Math.floor(Math.random() * 10));
    const formattedReturnDate = `${randomReturnDate.getFullYear()}-${(randomReturnDate.getMonth() + 1).toString().padStart(2, '0')}-${randomReturnDate.getDate().toString().padStart(2, '0')}`;
    cy.selectDate('[data-testid^="FlightSearchCalendar__"]', formattedReturnDate);

    // The number of adults
    cy.get('.sc-jHXLhC').should('exist').click();
    cy.get('.sc-jHXLhC').contains('1').click(); 

    // The cabin class
    cy.get('.sc-dPPMrM').should('exist').click();
    cy.get('.sc-dPPMrM').contains('Economy').click(); 

    // Submit the form
    cy.get('.col-lg-4 > .sc-hARARD > [data-testid="FlightSearchBox__SearchButton"]').should('exist').click();

    // Wait for the flight page to load
    cy.wait(2000);
    cy.get('.sc-jTNJqp > div').should('exist');

    // To verify flights are sorted by 'cheapest'
    cy.get('[data-testid="Cheapest__SortBy__selected"] > .sc-dhVevo').should('exist').click();
    cy.wait(5000); 

   // Fetch the minimum price and assert
cy.get('[data-testid="Collapsed_PriceFilter"]').scrollIntoView().click();
cy.wait(2000); 
cy.get('[data-testid="FlightSearchResult__PriceFilter__Min"]').should('be.visible').invoke('text').then((minPrice) => {
  cy.log(`Actual minimum price: '${minPrice}'`);

  // Use a regular expression to match the dynamic part of the price
  const pricePattern = /min USD (\d+)/;
  const match = minPrice.match(pricePattern);

  // Check if the pattern is matched and extract the dynamic part
  if (match) {
    const dynamicPrice = match[1];
    cy.log(`Extracted dynamic price: '${dynamicPrice}'`);
    cy.expect(dynamicPrice).to.not.be.empty;

  } else {
    console.error('Failed to match the price pattern');
  }
});

  });
});
