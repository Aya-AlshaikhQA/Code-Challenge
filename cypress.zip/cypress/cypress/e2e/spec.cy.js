// describe('template spec', () => {
//   it('passes', () => {
//     cy.visit('https://example.cypress.io')
//   })
// })

it ("Log something in cypress", function(){

  cy.log("Aya")
  
  })